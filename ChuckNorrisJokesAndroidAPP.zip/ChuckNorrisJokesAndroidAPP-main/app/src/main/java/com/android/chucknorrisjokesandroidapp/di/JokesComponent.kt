package com.android.chucknorrisjokesandroidapp.di

interface JokesComponent {

}